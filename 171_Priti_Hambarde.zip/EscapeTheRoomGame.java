import java.util.Scanner;

public class EscapeTheRoomGame {

    // Constants for inventory items
    private static final int KEY = 0;
    private static final int CODE = 1;

    // Game state variables
    private static boolean[] items = new boolean[2]; // items[0] = key, items[1] = code
    private static boolean doorOpen = false;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to 'Escape the Room: A Text-Based Adventure Game'!");

        // Game loop that continues until the player escapes
        while (!doorOpen) {
            printRoomStatus(); // Display room and item status
            printActions(); // Display available actions

            // Get the player's action choice with input validation
            int choice = getPlayerChoice(scanner);

            // Process the player's choice
            handleChoice(choice);
        }

        // Close scanner when the game ends
        scanner.close();
        System.out.println("Congratulations! You've escaped the room!");
    }

    // Prints the current status of the room and the items the player has
    private static void printRoomStatus() {
        System.out.println("\nYou are in a small locked room. There is a desk, a door, and some shelves.");

        // Display item status
        if (items[KEY] && items[CODE]) {
            System.out.println("You have all the necessary items to escape the room.");
        }
    }

    // Prints the list of possible actions for the player
    private static void printActions() {
        System.out.println("\nChoose an action:");
        System.out.println("1. Search the room.");
        System.out.println("2. Try to open the door.");
        System.out.println("3. Examine the desk.");
        System.out.println("4. Exit the game.");
        System.out.print("Enter your choice: ");
    }

    // Validates and retrieves the player's choice
    private static int getPlayerChoice(Scanner scanner) {
        int choice = -1;
        try {
            choice = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a number between 1 and 4.");
            scanner.nextLine(); // Clear the invalid input
        }
        return choice;
    }

    // Processes the player's choice based on the input
    private static void handleChoice(int choice) {
        switch (choice) {
            case 1:
                searchRoom();
                break;
            case 2:
                tryToOpenDoor();
                break;
            case 3:
                examineDesk();
                break;
            case 4:
                System.out.println("Exiting the game...");
                System.exit(0); // Exit the game
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Searches the room for items (key and code)
    private static void searchRoom() {
        if (!items[KEY]) {
            System.out.println("You found a key on the shelf.");
            items[KEY] = true; // Mark the key as found
        } else {
            System.out.println("You've already taken the key.");
        }

        if (!items[CODE]) {
            System.out.println("You found a piece of paper with a code written on it: 1234.");
            items[CODE] = true; // Mark the code as found
        } else {
            System.out.println("You've already found the code.");
        }
    }

    // Tries to open the door if the player has both the key and the code
    private static void tryToOpenDoor() {
        if (items[KEY] && items[CODE]) {
            System.out.println("You unlock the door with the key and use the code to disable the security system.");
            doorOpen = true; // Set doorOpen to true, ending the game
        } else {
            printMissingItems(); // Notify the player what they are missing
        }
    }

    // Prints which items the player still needs to open the door
    private static void printMissingItems() {
        if (!items[KEY] && !items[CODE]) {
            System.out.println("The door is locked. You need both the key and the code to open it.");
        } else if (!items[KEY]) {
            System.out.println("The door is locked. You need the key to open it.");
        } else {
            System.out.println("The door is locked. You need the code to disable the security system.");
        }
    }

    // Examines the desk and provides feedback
    private static void examineDesk() {
        System.out.println("The desk has some papers and a drawer.");
        if (!items[KEY]) {
            System.out.println("You found a locked drawer, but you don't have the key yet.");
        } else {
            System.out.println("You can now open the drawer, but there's nothing of interest inside.");
        }
    }
}
